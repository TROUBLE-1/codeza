<!DOCTYPE html>
<html lang="en">
<head>
	<title>lab</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">

</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/img-01.jpg');">
			<div class="wrap-login100 p-t-190 p-b-30">
				
                <?php 
include('config.php');
session_start();
if(isset($_POST['username']) and isset($_POST['password'])){

      $username =  $_POST['username'];
      $password = $_POST['password']; 
      $conn=oci_connect("system","Admin123","localhost/orcl");

      $query = "select * from users where username = '$username' and password = '$password'";

        $s = oci_parse($conn, $query);
        if(oci_execute($s)){
            $r = oci_fetch_array($s);
            if($r > 1){
                $_SESSION['username'] = $r[0];
                header("location: ./home.php");
        }
    }
    
  }
   
?>
                <form class="login100-form validate-form" method="post" action="index.php">
					<div class="login100-form-avatar">
						<img src="images/avatar-01.jpg" alt="AVATAR">
					</div>

					<span class="login100-form-title p-t-20 p-b-45" style="font-family:Fixedsys">
						
					</span>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Username is required">
						<input class="input100" type="text" name="username" placeholder="username">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Password is required">
						<input class="input100" type="password" name="password" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock"></i>
						</span>
					</div>

					<div class="container-login100-form-btn p-t-10">
						<button class="login100-form-btn">
							Login
						</button>
					</div>

					<div class="text-center w-full p-t-25 p-b-230">
						<p class="txt1">
				            <?php if(isset($error)){echo $error;} ?>
						</p>
					</div>

				
				</form>
			</div>
		</div>
	</div>

</body>
</html>