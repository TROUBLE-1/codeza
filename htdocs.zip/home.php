<?php session_start();
if(!isset($_SESSION['username'])){
    
  //  header("location: ./");
}
?>
<head>
<link href="./css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="./css/home.css" rel="stylesheet" id="bootstrap-css">
</head>

<div class="container emp-profile">
            
                <div class="row">
                    <div class="col-md-4">
                        <div class="profile-img">
                            <img src="images/profile.webp" alt=""/>
                            <div class="file btn btn-lg btn-primary">
                                Change Photo
                                <input type="file" name="file"/>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="profile-head">
                                    <h5>
                                       Welcome, <?php echo $_SESSION['username'];?>
                                    </h5>
                                    <h6>
                                       
                                    </h6>
                                    <p class="proile-rating"></p>
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">About</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <form method="get">
                    <div class="col-md-2">
                    <button type="button" class="btn btn-warning">
                        <a href="logout.php">Logout</a>
                        </button>
                    </div>
                    </form> 
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="profile-work">
                            <p>WORK LINK</p>
                            <a href="">Website Link</a><br/>
                            <a href="">Bootsnipp Profile</a><br/>
                            <a href="">Bootply Profile</a>
                            <p>SKILLS</p>
                            <a href="">Web Designer</a><br/>
                            <a href="">Web Developer</a><br/>
                            <a href="">WordPress</a><br/>
                            <a href="">WooCommerce</a><br/>
                            <a href="">PHP, .Net</a><br/>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="tab-content profile-tab" id="myTabContent">
                           
                          
                        </div>
                    </div>
                </div>
                      
        </div>

