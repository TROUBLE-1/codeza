<?php 
/*	$conn=oci_connect("system","Admin123","localhost/orcl");
	If (!$conn)
		echo 'Failed to connect to Oracle';
	
 
//oci_close($db);
*/ ?>

<?php

$c = oci_connect("HR", "DefaultSchema12345", "adb.us-ashburn-1.oraclecloud.com/");
if (!$c) {
    $m = oci_error();
    trigger_error("Could not connect to database: ". $m["message"], E_USER_ERROR);
}

// Create a table

$stmtarray = array(
    "BEGIN
         EXECUTE IMMEDIATE 'DROP TABLE mycloudtab';
         EXCEPTION
         WHEN OTHERS THEN
           IF SQLCODE NOT IN (-00942) THEN
             RAISE;
           END IF;
       END;",

    "CREATE TABLE mycloudtab (id NUMBER, data VARCHAR2(20))"
);

foreach ($stmtarray as $stmt) {
    $s = oci_parse($c, $stmt);
    if (!$s) {
        $m = oci_error($c);
        trigger_error("Could not parse statement: ". $m["message"], E_USER_ERROR);
    }
    $r = oci_execute($s);
    if (!$r) {
        $m = oci_error($s);
        trigger_error("Could not execute statement: ". $m["message"], E_USER_ERROR);
    }
}

// Insert some data

$data = [ [101, "Alpha" ], [102, "Beta" ], [103, "Gamma" ] ];

$s = oci_parse($c, "INSERT INTO mycloudtab VALUES (:1, :2)");
if (!$s) {
    $m = oci_error($c);
    trigger_error("Could not parse statement: ". $m["message"], E_USER_ERROR);
}

foreach ($data as $record) {
    oci_bind_by_name($s, ":1", $record[0]);
    oci_bind_by_name($s, ":2", $record[1]);
    oci_execute($s, OCI_NO_AUTO_COMMIT); // for PHP <= 5.3.1 use OCI_DEFAULT instead
    if (!$r) {
        $m = oci_error($s);
        trigger_error("Could not execute statement: ". $m["message"], E_USER_ERROR);
    }
}
oci_commit($c);

// Query the data

$s = oci_parse($c, "SELECT * FROM mycloudtab");
if (!$s) {
    $m = oci_error($c);
    trigger_error("Could not parse statement: ". $m["message"], E_USER_ERROR);
}
$r = oci_execute($s);
if (!$r) {
    $m = oci_error($s);
    trigger_error("Could not execute statement: ". $m["message"], E_USER_ERROR);
}

echo "<table border='1'>\n";

// Print column headings

$ncols = oci_num_fields($s);
echo "<tr>\n";
for ($i = 1; $i <= $ncols; ++$i) {
    $colname = oci_field_name($s, $i);
    echo "<th><b>".htmlspecialchars($colname,ENT_QUOTES|ENT_SUBSTITUTE)."</b></th>\n";
}
echo "</tr>\n";

// Print data

while (($row = oci_fetch_array($s, OCI_ASSOC+OCI_RETURN_NULLS)) != false) {
    echo "<tr>\n";
    foreach ($row as $item) {
        echo "<td>";
        echo $item !== null ? htmlspecialchars($item, ENT_QUOTES|ENT_SUBSTITUTE) : "&nbsp;";
        echo "</td>\n";
    }
    echo "</tr>\n";
}
echo "</table>\n";

?>