<?php 
	$conn=oci_connect("system","Admin123","orcl");
	If (!$conn)
		echo 'Failed to connect to Oracle';
	

//oci_close($db);
 ?>
